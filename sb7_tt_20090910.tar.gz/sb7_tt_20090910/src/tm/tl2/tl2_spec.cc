#include "tl2.h"
#include "../../constants.h"

namespace sb7 {
	::Thread *tl2_thread_desc[MAX_THREADS];
}
